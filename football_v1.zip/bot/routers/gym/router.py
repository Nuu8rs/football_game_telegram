from aiogram import Router
from .gym_handler import gym_router


gym_main_router = Router()
gym_main_router.include_routers(
    gym_router
)