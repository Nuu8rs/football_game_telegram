from aiogram import Router
from aiogram import Bot, F
from aiogram.types import Message, FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.filters import CommandStart

from bot.keyboards.menu_keyboard import main_menu
from database.models import UserBot, Character

start_router = Router()


@start_router.message(CommandStart())
async def start_command_handler(message: Message, state: FSMContext, user: UserBot):
    await state.clear()
    bot_name = await message.bot.get_my_name()
    await message.answer(f"Вітаємо у «{bot_name.name}»– найкращому симуляторі кар'єри футболіста!"\
                         "Тут ви зможете пройти шлях від молодого таланта до легенди світового футболу."\
                         "Розвивайте свої навички, прокачуйте персонажа, приєднуйся до команд та інших граців, беріть участь у великих турнірах і ведіть свою команду до перемоги."\
                         "Ваші рішення на полі та за його межами визначать долю вашої кар'єри. Готові стати новою зіркою футболу? Час почати свою подорож до футбольної величі!",
                         reply_markup=main_menu(user))
    
 