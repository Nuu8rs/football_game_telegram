from aiogram.filters.callback_data import CallbackData
from constants import Gender, PositionCharacter
from database.models import Character
from datetime import timedelta

class SelectGymType(CallbackData, prefix="select_gym_type"):
    gym_type: str
    
class SelectTimeGym(CallbackData, prefix="select_time_gym"):
    gym_time: timedelta
    gym_type: str
    