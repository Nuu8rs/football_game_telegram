import datetime
from sqlalchemy import Column, BigInteger, String, DateTime, ForeignKey, Integer, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy.orm import relationship
from config import PositionCharacter, Gender

Base = declarative_base()

class UserBot(Base):
    __tablename__ = 'users'
    
    id = Column(BigInteger, primary_key=True, index=True)
    user_id = Column(BigInteger, unique=True, index=True)  
    user_name = Column(String(255), index=True)  
    user_full_name = Column(String(255)) 
    user_time_register = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Связь с персонажами
    characters = relationship("Character", back_populates="owner", lazy="selectin")

class Character(Base):
    __tablename__ = 'characters'
    
    id = Column(BigInteger, primary_key=True, index=True)
    characters_user_id = Column(BigInteger, ForeignKey('users.user_id'))  
    
    name           = Column(String(255), index=True)
    technique      = Column(Integer, default=0)
    kicks          = Column(Integer, default=0)
    ball_selection = Column(Integer, default=0)
    speed          = Column(Integer, default=0)
    endurance      = Column(Integer, default=0)
    current_energy = Column(Integer, default=0)
    position       = Column(String(255))
    gender         = Column(String(255))
    
    character_in_training = Column(Boolean, default=False)
    
    created_at     = Column(DateTime, default=datetime.datetime.utcnow)
    
    owner = relationship("UserBot", back_populates="characters", lazy="selectin")

    @property
    def gender_enum(self):
        return Gender(self.gender) if self.gender else None

    @gender_enum.setter
    def gender_enum(self, value):
        if isinstance(value, Gender):
            self.gender = value.value

    @property
    def position_enum(self):
        return PositionCharacter(self.position) if self.position else None

    @position_enum.setter
    def position_enum(self, value):
        if isinstance(value, PositionCharacter):
            self.position = value.value

    @hybrid_property
    def max_energy(self) -> int:
        return int(self.endurance * 7)

    @hybrid_property
    def full_power(self) -> int:
        return int(self.technique + self.kicks + self.ball_selection + self.speed + self.endurance)
    
    @property
    def position_description(self):
        position_declensions = {
            PositionCharacter.MIDFIELDER: {
                Gender.MAN: "Півзахисник",
                Gender.WOMAN: "Півзахисниця"
            },
            PositionCharacter.DEFENDER: {
                Gender.MAN: "Захисник",
                Gender.WOMAN: "Захисниця"
            },
            PositionCharacter.GOALKEEPER: {
                Gender.MAN: "Воротар",
                Gender.WOMAN: "Воротарка"
            },
            PositionCharacter.ATTACKER: {
                Gender.MAN: "Нападник",
                Gender.WOMAN: "Нападниця"
            }
        }
        
        position_enum = self.position_enum
        gender_enum = self.gender_enum
        if position_enum and gender_enum:
            return position_declensions[position_enum][gender_enum]
        return None