from aiogram.utils.keyboard import ReplyKeyboardBuilder
from database.models import UserBot

def main_menu(user: UserBot):
    keyboard = ReplyKeyboardBuilder()
    if not user.characters:
        keyboard.button(text="⚽️ Створити персонажа")
    else:
        keyboard.button(text="⚽️ Мій персонаж")
        keyboard.button(text="🧤 Піти на тренування")
        keyboard.button(text="🎪 Мій клуб")
        keyboard.button(text= "🏟 Стадіон")
    
    return keyboard.adjust(1).as_markup()