from aiogram.utils.keyboard import InlineKeyboardBuilder
from ..callbacks.gym_calbacks import SelectGymType, SelectTimeGym
from constants import Gender, PositionCharacter
from database.models import Character
from datetime import timedelta

def select_type_gym():
    return (InlineKeyboardBuilder()
        .button(text = "🎯 Техніку"      , callback_data=SelectGymType(gym_type="technique"))
        .button(text = "🥋 Удари"        , callback_data=SelectGymType(gym_type="kicks"))
        .button(text = "🛡️ Відбір м’яча" , callback_data=SelectGymType(gym_type="ball_selection"))
        .button(text = "⚡ Швидкість"    , callback_data=SelectGymType(gym_type="speed"))
        .button(text = "🏃 Витривалість" , callback_data=SelectGymType(gym_type="endurance"))
        .adjust(2)
        .as_markup()
            )
def select_time_to_gym(gym_type: str):
    return (InlineKeyboardBuilder()
            .button(text="🕑 30 хвилин"  , callback_data=SelectTimeGym(gym_time=timedelta(minutes = 30) , gym_type = gym_type))
            .button(text="🕒 60 хвилин"  , callback_data=SelectTimeGym(gym_time=timedelta(minutes = 60) , gym_type = gym_type))
            .button(text="🕓 90 хвилин"  , callback_data=SelectTimeGym(gym_time=timedelta(minutes = 90) , gym_type = gym_type))
            .button(text="🕔 120 хвилин" , callback_data=SelectTimeGym(gym_time=timedelta(minutes = 120), gym_type = gym_type))
            .button(text="⬅️ Назад до вибору", callback_data="back_to_select_gym_type")
            .adjust(2,2,1)
            .as_markup()
            )