from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder
from ..callbacks.league_callbacks import JoinToFight

def keyboard_to_join_character_to_fight(match_id: int):
    return (
        InlineKeyboardBuilder()
        .button(text = "⚽️ Приєднатися до битви!", callback_data=JoinToFight(
            match_id=match_id
        ))
        .as_markup()
    )
    
def menu_league_zone():
    return(ReplyKeyboardBuilder()
           .button(text = "Зареєструватися в матч")
           .button(text = "Результати")
           .button(text = "Таблиця")
           .button(text = "Календар ігор")
           .button(text = "Площа переможців")
           .adjust(2)
           .as_markup()
           )
    