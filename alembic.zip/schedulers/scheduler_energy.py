from aiogram import Bot

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.jobstores.base import JobLookupError


from database.models import Character
from services.character_service import CharacterService
from datetime import datetime, timedelta

from constants import chance_add_point, const_name_characteristics, time_resete_energy
from logging_config import logger
from utils.randomaizer import check_chance


class EnergyResetScheduler:
    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self.scheduler.add_job(self.reset_energy_character, time_resete_energy)

    async def reset_energy_character(self):
        print("Resetting energy for all characters...")

    def start(self):
        self.scheduler.start()

    def stop(self):
        self.scheduler.shutdown()
        
        
