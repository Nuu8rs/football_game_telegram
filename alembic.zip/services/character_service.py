from database.models import Character
from database.session import get_session
from sqlalchemy.future import select
from config import DatabaseType

class CharacterService:

    
    @classmethod
    async def create_character(cls, character_obj: Character) -> Character:
        character_obj.gender = character_obj.gender.value
        character_obj.position = character_obj.position.value
        
        async for session in get_session():
            async with session.begin():
                try:
                    session.add(character_obj)
                except:
                    pass
                merged_obj = await session.merge(character_obj)
                await session.commit()
                return merged_obj
            
    @classmethod
    async def update_character_field(cls, character_obj: Character, param: str, add_point: int) -> Character:
        async for session in get_session():
            async with session.begin():
                try:
                    session.add(character_obj)
                except:
                    pass
                merged_obj = await session.merge(character_obj)
                current_value = getattr(merged_obj, param, 0)
                setattr(merged_obj, param, current_value + add_point)
                await session.commit()
         

    @classmethod
    async def consume_energy(cls, character_obj: Character, energy_consumed: int) -> Character:
        async for session in get_session():
            async with session.begin():
                try:
                    session.add(character_obj)
                except:
                    pass
                merged_obj = await session.merge(character_obj)
                current_energy = getattr(merged_obj, 'current_energy', 0)
                new_energy = current_energy - energy_consumed
                setattr(merged_obj, 'current_energy', max(new_energy, 0))
                await session.commit()
     
    @classmethod
    async def toggle_character_training_status(cls, character_obj: Character) -> Character:
        async for session in get_session():
            async with session.begin():
                try:
                    session.add(character_obj)
                except:
                    pass
                merged_obj = await session.merge(character_obj)
                current_status = getattr(merged_obj, 'character_in_training', False)
                new_status = not current_status
                setattr(merged_obj, 'character_in_training', new_status)
                await session.commit()
                
    @classmethod        
    async def update_character_club_id(cls,character: Character ,club_id: int):
        async for session in get_session():
            async with session.begin():
                try:
                    session.add(character)
                except:
                    pass
                character.club_id = club_id
                merged_obj = await session.merge(character)
                await session.commit()
                return merged_obj